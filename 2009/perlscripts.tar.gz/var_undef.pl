#!/usr/bin/perl -w

  print "Trying an undefined variable: $var_undef.\n";

#	End var_undef.pl
