#!/usr/bin/perl -w
 use strict;
 use Tk;
 my $main = MainWindow->new();
 MainLoop();
