#!/usr/bin/perl -w

@alpha = ('a'..'z');

print join " ", reverse @alpha;

print "\n";
