#!/usr/bin/perl
print "<html><body>\n\n";
print "<h1>mod_perl rules!</h1>\n";
print "</body></html>\n";