#!/usr/bin/perl -w

@colours = ("yellow", "green", "blue", "black");

for ($i=0;$i<4;$i++)
{
    print $colours[$i],"\n";
}

