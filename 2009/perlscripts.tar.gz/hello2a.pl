#!/usr/bin/perl

  print "\tHello\fWorld\f!\n";
  
#	End hello2a.pl
