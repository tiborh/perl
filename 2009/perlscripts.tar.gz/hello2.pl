#!/usr/bin/perl

  print "\t","Hello","\f","World","\f","!","\n";
  
#	End hello2.pl
