#!/usr/bin/perl -w

use 5.010;

say "Hello world!";
  
#	End say.pl
