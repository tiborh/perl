#!/usr/bin/perl -w

$var_badly_defined = $var_undef + 233;

print "Trying a badly defined variable: $var_badly_defined.\n";

#	End var_undef2.pl
