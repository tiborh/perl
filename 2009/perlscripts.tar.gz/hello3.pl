#!/usr/bin/perl -w

  print "Hello World!\n";

#	End hello3.pl
