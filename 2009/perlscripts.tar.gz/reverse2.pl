#!/usr/bin/perl -w

@alpha = ("scooby", "dooby", "doo");
print(join " ", reverse(@alpha));
print("\n");
